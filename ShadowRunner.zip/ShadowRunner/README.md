# Shadow Runner (prototype)
Open this folder in Android Studio, let Gradle sync, press Run.
Controls: ◀ ▶ move, JUMP, hold GRAB while falling next to a ledge to hang, press JUMP while hanging to climb.
Physics constants are at the top of GameView.kt.
