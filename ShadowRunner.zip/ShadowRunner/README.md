# Shadow Runner (prototype)
Open this folder in Android Studio, let Gradle sync, press Run.
Pixel-art visuals are drawn in code (Art.kt). Controls: ◀ ▶ move, JUMP, ledges grab automatically; hold JUMP to climb, DOWN to drop.
Physics constants are at the top of GameView.kt.
