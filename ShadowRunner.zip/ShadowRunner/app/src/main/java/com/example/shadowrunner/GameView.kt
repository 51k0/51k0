package com.example.shadowrunner

import android.content.Context
import android.graphics.*
import android.view.*
import kotlin.math.*

/** Original platformer in the classic "rotoscoped-era" style: ledge grabs, fall damage, spikes. Units = tiles. */
class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback, Runnable {
    // ---- Tunables: tweak these to change the feel ----
    private val GRAV = 28f          // tiles/s^2
    private val RUN = 5f          // tiles/s
    private val JUMP = 11f          // initial jump speed (running jump ~3.5 tiles far)
    private val HURT_VY = 14.5f     // landing speed that costs 1 HP (~4 tile fall)
    private val DEATH_VY = 19f      // landing speed that kills (~6.5 tile fall)
    private val PW = 0.3f           // player half width
    private val PH = 1.6f           // player height

    private var thread: Thread? = null
    @Volatile private var running = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var level = 0
    private var g = Array(1) { CharArray(1) }
    private var W = 0; private var H = 0
    private var px = 0f; private var py = 0f; private var vx = 0f; private var vy = 0f
    private var onGround = false; private var hanging = false
    private var face = 1; private var hp = 3
    private var hangTx = 0; private var hangTy = 0
    private var dead = false; private var won = false
    private var sx = 0f; private var sy = 0f

    private var bL = false; private var bR = false; private var bJ = false; private var bD = false
    private var prevJ = false
    private var dropCd = 0f; private var hangT = 0f
    private val rects = Array(4) { RectF() }

    init { holder.addCallback(this); load(0) }

    // ---------- Levels ----------
    private fun fill(x1: Int, y1: Int, x2: Int, y2: Int, c: Char = '#') {
        for (y in y1..y2) for (x in x1..x2) g[y][x] = c
    }

    private fun load(i: Int) {
        level = i
        if (i == 0) {
            W = 40; H = 12; g = Array(H) { CharArray(W) { '.' } }
            fill(0, 0, W - 1, 0); fill(0, 0, 0, H - 1); fill(W - 1, 0, W - 1, H - 1)
            fill(0, 10, W - 1, 11); fill(12, 10, 13, 11, '.')       // floor with pit
            fill(16, 8, 19, 8); fill(22, 6, 27, 6)                  // ledges
            fill(30, 8, 31, 9)                                      // 2-tile wall to climb
            fill(24, 9, 25, 9, '^'); g[9][37] = 'E'
            sx = 2.5f; sy = 10f
        } else {
            W = 40; H = 16; g = Array(H) { CharArray(W) { '.' } }
            fill(0, 0, W - 1, 0); fill(0, 0, 0, H - 1); fill(W - 1, 0, W - 1, H - 1)
            fill(0, 14, W - 1, 15)
            fill(1, 6, 8, 6); fill(11, 9, 15, 9); fill(18, 12, 22, 12)
            fill(26, 13, 27, 13, '^'); fill(31, 12, 32, 13); g[13][37] = 'E'
            sx = 3.5f; sy = 6f
        }
        px = sx; py = sy; vx = 0f; vy = 0f; hp = 3
        hanging = false; dead = false; won = false; face = 1
    }

    private fun solid(x: Int, y: Int): Boolean =
        if (x < 0 || x >= W || y < 0) true else if (y >= H) false else g[y][x] == '#'

    private fun hits(x: Float, y: Float): Boolean {
        val x1 = floor(x - PW).toInt(); val x2 = floor(x + PW).toInt()
        val y1 = floor(y - PH).toInt(); val y2 = floor(y - 0.001f).toInt()
        for (ty in y1..y2) for (tx in x1..x2) if (solid(tx, ty)) return true
        return false
    }

    // ---------- Update ----------
    private fun update(dt: Float) {
        val jumpEdge = bJ && !prevJ
        prevJ = bJ
        if (dead || won) return
        val dir = (if (bR) 1 else 0) - (if (bL) 1 else 0)

        if (dropCd > 0) dropCd -= dt
        if (hanging) {
            hangT += dt
            if (bD) { hanging = false; dropCd = 0.4f; vy = 0f }
            else if (bJ && hangT > 0.2f && !solid(hangTx, hangTy - 1) && !solid(hangTx, hangTy - 2)) {
                px = hangTx + 0.5f; py = hangTy.toFloat(); vy = 0f; hanging = false; dropCd = 0.3f
            }
            return
        }

        // Classic feel: full control on the ground, momentum locked in the air.
        if (onGround) { vx = dir * RUN; if (dir != 0) face = dir }
        if (jumpEdge && onGround) vy = -JUMP
        if (onGround && vx != 0f) animT += dt else if (onGround) animT = 0f
        vy = min(vy + GRAV * dt, 25f)

        val nx = px + vx * dt
        if (!hits(nx, py)) px = nx

        val ny = py + vy * dt
        if (!hits(px, ny)) { py = ny; onGround = false }
        else {
            if (vy > 0) {
                py = floor(ny - 0.001f)
                onGround = true
                if (vy > DEATH_VY) { hp = 0 } else if (vy > HURT_VY) { hp-- }
                if (hp <= 0) dead = true
            }
            vy = 0f
        }

        if (!onGround && vy > -4f && dropCd <= 0f) tryGrab()   // auto-grab, no button

        val tx = floor(px).toInt(); val ty = floor(py - 0.1f).toInt()
        if (tx in 0 until W && ty in 0 until H) {
            if (g[ty][tx] == '^') dead = true
            if (g[ty][tx] == 'E') won = true
        }
        if (py > H + 2) dead = true
    }

    private fun tryGrab() {
        val cx = floor(px + face * 0.5f).toInt()
        val headY = py - PH
        val ty = headY.roundToInt()
        if (abs(headY - ty) < 0.6f && solid(cx, ty) && !solid(cx, ty - 1)) {
            hanging = true; vy = 0f; hangT = 0f
            hangTx = cx; hangTy = ty
            py = ty + PH
            px = if (face > 0) cx - PW - 0.01f else cx + 1f + PW + 0.01f
        }
    }

    // ---------- Draw ----------
    private val nf = Paint()
    private val skyPaint = Paint(); private var skyH = 0
    private var animT = 0f

    private fun hash(x: Int, y: Int): Int { val v = (x * 73856093) xor (y * 19349663); return (v xor (v ushr 13)) and 0x7fffffff }

    private fun blit(c: Canvas, b: Bitmap, x: Float, y: Float, k: Float, flip: Boolean = false) {
        val w = b.width * k; val h = b.height * k
        if (flip) { c.save(); c.scale(-1f, 1f, x + w / 2, y + h / 2) }
        c.drawBitmap(b, null, RectF(x, y, x + w, y + h), nf)
        if (flip) c.restore()
    }

    private fun drawGame(c: Canvas) {
        val w = c.width.toFloat(); val h = c.height.toFloat()
        val k = max(2, (h / 160f).roundToInt()).toFloat()   // one art pixel = k screen pixels (keeps pixels crisp)
        val s = 16 * k
        val camX = (px * s - w / 2).coerceIn(0f, max(0f, W * s - w))
        val camY = (py * s - h * 0.65f).coerceIn(0f, max(0f, H * s - h))
        val t = System.nanoTime() / 1e9f

        // Sky, sun, drifting clouds
        if (skyH != h.toInt()) {
            skyPaint.shader = LinearGradient(0f, 0f, 0f, h, 0xFF5db7ee.toInt(), 0xFFd2f0fb.toInt(), Shader.TileMode.CLAMP); skyH = h.toInt()
        }
        c.drawRect(0f, 0f, w, h, skyPaint)
        blit(c, Art.sun, w - 30 * k, 5 * k, 2 * k)
        for (i in 0 until 4) {
            val cw = 80 * k; val span = w + cw * 2
            val x = ((i * span / 4f + t * 5f * k - camX * 0.1f) % span + span) % span - cw
            blit(c, Art.cloud, x, (6 + (i * 7) % 18) * k, 2 * k)
        }
        // Parallax hills
        for (layer in 0..1) {
            val bm = if (layer == 0) Art.hillFar else Art.hillNear
            val base = if (layer == 0) Art.HILL_FAR_BASE else Art.HILL_NEAR_BASE
            val par = 0.15f + 0.15f * layer
            val top = h * (0.42f + 0.12f * layer) - camY * (0.1f + 0.05f * layer)
            val tw = 192 * k
            var x = -((camX * par) % tw)
            while (x < w) { blit(c, bm, x, top, k); x += tw }
            paint.color = base.toInt()
            if (top + 64 * k < h) c.drawRect(0f, top + 64 * k, w, h, paint)
        }

        val tx0 = max(0, (camX / s).toInt() - 1); val tx1 = min(W - 1, ((camX + w) / s).toInt() + 1)
        val ty0 = max(0, (camY / s).toInt() - 2); val ty1 = min(H - 1, ((camY + h) / s).toInt() + 1)

        // Scenery on grass (drawn first so ground overlaps trunks)
        for (ty in max(1, ty0)..ty1) for (tx in tx0..tx1) {
            if (g[ty][tx] != '#' || solid(tx, ty - 1)) continue
            val free = (tx - 1..tx + 1).all { it in 0 until W && g[ty - 1][it] == '.' }
            val l = tx * s - camX; val tp = ty * s - camY
            val hv = hash(tx, ty) % 24
            if (!free) continue
            val air3 = ty >= 4 && (1..3).all { !solid(tx, ty - it) }
            when {
                hv == 0 && air3 -> blit(c, Art.tree, l + 8 * k - 16 * k, tp - 46 * k, k)
                hv in 1..3 -> blit(c, Art.bush, l + 8 * k - 10 * k, tp - 10 * k, k)
                hv in 4..8 -> { val fx = l + (hash(tx, 5) % 12 + 2) * k
                    paint.color = 0xFF3f8a2f.toInt(); c.drawRect(fx, tp - 3 * k, fx + k, tp, paint)
                    paint.color = intArrayOf(0xFFf29bb8.toInt(), 0xFFffe066.toInt(), 0xFFffffff.toInt(), 0xFFc79bf2.toInt())[hv % 4]
                    c.drawRect(fx - k, tp - 5 * k, fx + 2 * k, tp - 3 * k, paint) }
            }
        }
        // Tiles
        for (ty in ty0..ty1) for (tx in tx0..tx1) {
            val ch = g[ty][tx]; if (ch == '.') continue
            val l = tx * s - camX; val tp = ty * s - camY
            when (ch) {
                '#' -> { val hv = hash(tx, ty) % 4
                         blit(c, if (solid(tx, ty - 1)) Art.dirt[hv] else Art.grass[hv], l, tp, k) }
                '^' -> blit(c, Art.stakes, l, tp, k)
                'E' -> blit(c, Art.door, l, tp + s - 24 * k, k)
            }
        }

        // Hero
        val frame = when {
            hanging -> 4
            !onGround -> 3
            vx != 0f -> intArrayOf(1, 0, 2, 0)[(animT / 0.1f).toInt() % 4]
            else -> 0
        }
        val hx = px * s - camX - 8 * k; val hy = py * s - camY - 26 * k
        if (dead) { c.save(); c.rotate(90f * face, px * s - camX, py * s - camY); blit(c, Art.player[0], hx, hy, k, face < 0); c.restore() }
        else blit(c, Art.player[frame], hx, hy, k, face < 0)

        // HUD
        for (i in 0 until 3) blit(c, if (i < hp) Art.heartFull else Art.heartEmpty, s * 0.3f + i * 17 * k, s * 0.3f, 2 * k)
        paint.color = Color.WHITE; paint.textSize = s * 0.5f
        c.drawText("Level ${level + 1}", s * 0.3f + 3 * 17 * k + s * 0.3f, s * 0.3f + 12 * k, paint)
        val bs = h * 0.28f
        rects[0].set(bs * 0.2f, h - bs * 1.2f, bs * 1.2f, h - bs * 0.2f)
        rects[1].set(bs * 1.4f, h - bs * 1.2f, bs * 2.4f, h - bs * 0.2f)
        rects[2].set(w - bs * 2.4f, h - bs * 1.2f, w - bs * 1.4f, h - bs * 0.2f)
        rects[3].set(w - bs * 1.2f, h - bs * 1.2f, w - bs * 0.2f, h - bs * 0.2f)
        val names = arrayOf("◀", "▶", "DOWN", "JUMP")
        for (i in 0..3) {
            paint.color = Color.argb(90, 255, 255, 255); c.drawRoundRect(rects[i], 20f, 20f, paint)
            paint.color = Color.WHITE; paint.textSize = bs * 0.25f
            c.drawText(names[i], rects[i].left + bs * 0.08f, rects[i].centerY() + bs * 0.08f, paint)
        }
        if (dead || won) {
            paint.textSize = s * 0.8f
            c.drawText(if (dead) "You died. Tap to retry" else "Level clear! Tap to continue", w * 0.2f, h * 0.4f, paint)
        }
    }

    // ---------- Input ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val up = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        bL = false; bR = false; bJ = false; bD = false
        if (!up) for (i in 0 until e.pointerCount) {
            if (e.actionMasked == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
            val x = e.getX(i); val y = e.getY(i)
            if (rects[0].contains(x, y)) bL = true
            if (rects[1].contains(x, y)) bR = true
            if (rects[2].contains(x, y)) bD = true
            if (rects[3].contains(x, y)) bJ = true
        }
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            if (dead) load(level) else if (won) load((level + 1) % 2)
        }
        return true
    }

    // ---------- Loop ----------
    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min((now - last) / 1e9f, 0.033f); last = now
            update(dt)
            val c = holder.lockCanvas() ?: continue
            try { drawGame(c) } finally { holder.unlockCanvasAndPost(c) }
            Thread.sleep(8)
        }
    }
    override fun surfaceCreated(h: SurfaceHolder) { running = true; thread = Thread(this).also { it.start() } }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) {}
    override fun surfaceDestroyed(h: SurfaceHolder) { running = false; thread?.join() }
}
