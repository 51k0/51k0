package com.example.shadowrunner

import android.content.Context
import android.graphics.*
import android.view.*
import kotlin.math.*

/** Original platformer in the classic "rotoscoped-era" style: ledge grabs, fall damage, spikes. Units = tiles. */
class GameView(ctx: Context) : SurfaceView(ctx), SurfaceHolder.Callback, Runnable {
    // ---- Tunables: tweak these to change the feel ----
    private val GRAV = 28f          // tiles/s^2
    private val RUN = 4.5f          // tiles/s
    private val JUMP = 9f           // initial jump speed
    private val HURT_VY = 14.5f     // landing speed that costs 1 HP (~4 tile fall)
    private val DEATH_VY = 19f      // landing speed that kills (~6.5 tile fall)
    private val PW = 0.3f           // player half width
    private val PH = 1.6f           // player height

    private var thread: Thread? = null
    @Volatile private var running = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var level = 0
    private var g = Array(1) { CharArray(1) }
    private var W = 0; private var H = 0
    private var px = 0f; private var py = 0f; private var vx = 0f; private var vy = 0f
    private var onGround = false; private var hanging = false
    private var face = 1; private var hp = 3
    private var hangTx = 0; private var hangTy = 0
    private var dead = false; private var won = false
    private var sx = 0f; private var sy = 0f

    private var bL = false; private var bR = false; private var bJ = false; private var bG = false
    private var prevJ = false
    private val rects = Array(4) { RectF() }

    init { holder.addCallback(this); load(0) }

    // ---------- Levels ----------
    private fun fill(x1: Int, y1: Int, x2: Int, y2: Int, c: Char = '#') {
        for (y in y1..y2) for (x in x1..x2) g[y][x] = c
    }

    private fun load(i: Int) {
        level = i
        if (i == 0) {
            W = 40; H = 12; g = Array(H) { CharArray(W) { '.' } }
            fill(0, 0, W - 1, 0); fill(0, 0, 0, H - 1); fill(W - 1, 0, W - 1, H - 1)
            fill(0, 10, W - 1, 11); fill(12, 10, 13, 11, '.')       // floor with pit
            fill(16, 8, 19, 8); fill(22, 6, 27, 6)                  // ledges
            fill(30, 8, 31, 9)                                      // 2-tile wall to climb
            fill(24, 9, 25, 9, '^'); g[9][37] = 'E'
            sx = 2.5f; sy = 10f
        } else {
            W = 40; H = 16; g = Array(H) { CharArray(W) { '.' } }
            fill(0, 0, W - 1, 0); fill(0, 0, 0, H - 1); fill(W - 1, 0, W - 1, H - 1)
            fill(0, 14, W - 1, 15)
            fill(1, 6, 8, 6); fill(11, 9, 15, 9); fill(18, 12, 22, 12)
            fill(26, 13, 27, 13, '^'); fill(31, 12, 32, 13); g[13][37] = 'E'
            sx = 3.5f; sy = 6f
        }
        px = sx; py = sy; vx = 0f; vy = 0f; hp = 3
        hanging = false; dead = false; won = false; face = 1
    }

    private fun solid(x: Int, y: Int): Boolean =
        if (x < 0 || x >= W || y < 0) true else if (y >= H) false else g[y][x] == '#'

    private fun hits(x: Float, y: Float): Boolean {
        val x1 = floor(x - PW).toInt(); val x2 = floor(x + PW).toInt()
        val y1 = floor(y - PH).toInt(); val y2 = floor(y - 0.001f).toInt()
        for (ty in y1..y2) for (tx in x1..x2) if (solid(tx, ty)) return true
        return false
    }

    // ---------- Update ----------
    private fun update(dt: Float) {
        val jumpEdge = bJ && !prevJ
        prevJ = bJ
        if (dead || won) return
        val dir = (if (bR) 1 else 0) - (if (bL) 1 else 0)

        if (hanging) {
            if (!bG) { hanging = false }
            else if (jumpEdge && !solid(hangTx, hangTy - 1) && !solid(hangTx, hangTy - 2)) {
                px = hangTx + 0.5f; py = hangTy.toFloat(); vy = 0f; hanging = false
            }
            return
        }

        vx = dir * RUN
        if (dir != 0) face = dir
        if (jumpEdge && onGround) vy = -JUMP
        vy = min(vy + GRAV * dt, 25f)

        val nx = px + vx * dt
        if (!hits(nx, py)) px = nx

        val ny = py + vy * dt
        if (!hits(px, ny)) { py = ny; onGround = false }
        else {
            if (vy > 0) {
                py = floor(ny - 0.001f)
                onGround = true
                if (vy > DEATH_VY) { hp = 0 } else if (vy > HURT_VY) { hp-- }
                if (hp <= 0) dead = true
            }
            vy = 0f
        }

        if (bG && !onGround && vy > 0) tryGrab()

        val tx = floor(px).toInt(); val ty = floor(py - 0.1f).toInt()
        if (tx in 0 until W && ty in 0 until H) {
            if (g[ty][tx] == '^') dead = true
            if (g[ty][tx] == 'E') won = true
        }
        if (py > H + 2) dead = true
    }

    private fun tryGrab() {
        val cx = floor(px + face * 0.5f).toInt()
        val headY = py - PH
        val ty = headY.roundToInt()
        if (abs(headY - ty) < 0.5f && solid(cx, ty) && !solid(cx, ty - 1)) {
            hanging = true; vy = 0f
            hangTx = cx; hangTy = ty
            py = ty + PH
            px = if (face > 0) cx - PW - 0.01f else cx + 1f + PW + 0.01f
        }
    }

    // ---------- Draw ----------
    private fun draw(c: Canvas) {
        val w = c.width.toFloat(); val h = c.height.toFloat()
        val s = h / 10f
        c.drawColor(Color.rgb(20, 18, 32))
        val camX = (px * s - w / 2).coerceIn(0f, max(0f, W * s - w))
        val camY = (py * s - h * 0.65f).coerceIn(0f, max(0f, H * s - h))
        for (ty in 0 until H) for (tx in 0 until W) {
            val ch = g[ty][tx]; if (ch == '.') continue
            val l = tx * s - camX; val t = ty * s - camY
            if (l > w || l + s < 0 || t > h || t + s < 0) continue
            when (ch) {
                '#' -> { paint.color = Color.rgb(110, 90, 70); c.drawRect(l, t, l + s, t + s, paint)
                         paint.color = Color.rgb(70, 55, 45); c.drawRect(l + 2, t + 2, l + s - 2, t + s - 2, paint) }
                '^' -> { paint.color = Color.LTGRAY
                         for (k in 0 until 4) { val p = Path(); val a = l + k * s / 4
                             p.moveTo(a, t + s); p.lineTo(a + s / 8, t + s * 0.4f); p.lineTo(a + s / 4, t + s); c.drawPath(p, paint) } }
                'E' -> { paint.color = Color.rgb(240, 200, 60); c.drawRect(l + s * 0.2f, t, l + s * 0.8f, t + s, paint) }
            }
        }
        // Player (placeholder art - replace with your own sprites)
        val pl = (px - PW) * s - camX; val pt = (py - PH) * s - camY
        paint.color = Color.rgb(230, 230, 240); c.drawRect(pl, pt + s * 0.4f, pl + 2 * PW * s, pt + PH * s, paint)
        paint.color = Color.rgb(240, 190, 150); c.drawCircle(pl + PW * s, pt + s * 0.25f, s * 0.22f, paint)
        paint.color = Color.RED; c.drawRect(pl + PW * s + face * PW * s * 0.6f, pt + s * 0.2f, pl + PW * s + face * PW * s * 1.2f, pt + s * 0.3f, paint)

        // HUD + buttons
        paint.color = Color.WHITE; paint.textSize = s * 0.5f
        c.drawText("HP " + "♥".repeat(max(hp, 0)) + "   Level ${level + 1}", s * 0.3f, s * 0.7f, paint)
        val bs = h * 0.28f
        rects[0].set(bs * 0.2f, h - bs * 1.2f, bs * 1.2f, h - bs * 0.2f)
        rects[1].set(bs * 1.4f, h - bs * 1.2f, bs * 2.4f, h - bs * 0.2f)
        rects[2].set(w - bs * 2.4f, h - bs * 1.2f, w - bs * 1.4f, h - bs * 0.2f)
        rects[3].set(w - bs * 1.2f, h - bs * 1.2f, w - bs * 0.2f, h - bs * 0.2f)
        val names = arrayOf("◀", "▶", "GRAB", "JUMP")
        for (i in 0..3) {
            paint.color = Color.argb(90, 255, 255, 255); c.drawRoundRect(rects[i], 20f, 20f, paint)
            paint.color = Color.WHITE; paint.textSize = bs * 0.25f
            c.drawText(names[i], rects[i].left + bs * 0.08f, rects[i].centerY() + bs * 0.08f, paint)
        }
        if (dead || won) {
            paint.textSize = s * 0.8f
            c.drawText(if (dead) "You died. Tap to retry" else "Level clear! Tap to continue", w * 0.2f, h * 0.4f, paint)
        }
    }

    // ---------- Input ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val up = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        bL = false; bR = false; bJ = false; bG = false
        if (!up) for (i in 0 until e.pointerCount) {
            if (e.actionMasked == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
            val x = e.getX(i); val y = e.getY(i)
            if (rects[0].contains(x, y)) bL = true
            if (rects[1].contains(x, y)) bR = true
            if (rects[2].contains(x, y)) bG = true
            if (rects[3].contains(x, y)) bJ = true
        }
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            if (dead) load(level) else if (won) load((level + 1) % 2)
        }
        return true
    }

    // ---------- Loop ----------
    override fun run() {
        var last = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val dt = min((now - last) / 1e9f, 0.033f); last = now
            update(dt)
            val c = holder.lockCanvas() ?: continue
            try { draw(c) } finally { holder.unlockCanvasAndPost(c) }
            Thread.sleep(8)
        }
    }
    override fun surfaceCreated(h: SurfaceHolder) { running = true; thread = Thread(this).also { it.start() } }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) {}
    override fun surfaceDestroyed(h: SurfaceHolder) { running = false; thread?.join() }
}
