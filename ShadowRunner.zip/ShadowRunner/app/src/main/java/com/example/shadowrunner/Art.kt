package com.example.shadowrunner

import android.graphics.*
import java.util.Random
import kotlin.math.*

/** All art is drawn in code as tiny pixel bitmaps (original, cozy farm-sim style). 1 bitmap pixel = k screen pixels. */
object Art {
    private fun bmp(w: Int, h: Int, f: (Canvas, Paint) -> Unit): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val p = Paint(); p.isAntiAlias = false
        f(Canvas(b), p); return b
    }
    private fun Canvas.r(p: Paint, col: Long, x: Int, y: Int, w: Int = 1, h: Int = 1) {
        p.color = col.toInt(); drawRect(x.toFloat(), y.toFloat(), (x + w).toFloat(), (y + h).toFloat(), p)
    }
    private fun blobs(c: Canvas, p: Paint, w: Int, h: Int, bl: List<IntArray>, dark: Long, mid: Long, light: Long, hi: Long, seed: Int) {
        val rnd = Random(seed.toLong())
        for (y in 0 until h) for (x in 0 until w) {
            for (b in bl) {
                val dx = x - b[0]; val dy = y - b[1]
                if (dx * dx + dy * dy <= b[2] * b[2]) {
                    val l = (dx + dy) / b[2].toFloat()
                    var col = if (l < -0.45f) light else if (l > 0.35f) dark else mid
                    if (rnd.nextInt(100) < 6) col = hi
                    c.r(p, col, x, y); break
                }
            }
        }
    }

    // ---- Tiles ----
    private fun mkDirt(seed: Int) = bmp(16, 16) { c, p ->
        val rnd = Random(seed.toLong())
        c.r(p, 0xFF8b5a2b, 0, 0, 16, 16)
        repeat(16) { c.r(p, if (rnd.nextBoolean()) 0xFF70451f else 0xFFa56d3a, rnd.nextInt(16), rnd.nextInt(16), 1 + rnd.nextInt(2), 1) }
        if (rnd.nextInt(3) == 0) { val x = rnd.nextInt(11); val y = rnd.nextInt(11); c.r(p, 0xFF8e8e96, x, y, 3, 2); c.r(p, 0xFFb4b4bc, x, y, 2, 1) }
    }
    private fun mkGrass(seed: Int) = bmp(16, 16) { c, p ->
        val rnd = Random(seed.toLong())
        c.drawBitmap(mkDirt(seed + 99), 0f, 0f, null)
        for (x in 0 until 16) {
            c.r(p, 0xFF5aa23a, x, 0, 1, 4 + rnd.nextInt(3))
            c.r(p, 0xFF7fc24b, x, 0, 1, 2)
            if (rnd.nextInt(4) == 0) c.r(p, 0xFF9de063, x, 0, 1, 1)
        }
    }
    val dirt = List(4) { mkDirt(it + 1) }
    val grass = List(4) { mkGrass(it + 11) }

    val stakes = bmp(16, 16) { c, p ->
        for (x0 in intArrayOf(0, 6, 12)) {
            c.r(p, 0xFF8a5a2b, x0, 8, 4, 8); c.r(p, 0xFF8a5a2b, x0 + 1, 4, 2, 4)
            c.r(p, 0xFFc89a5a, x0 + 1, 2, 1, 2); c.r(p, 0xFF6b4420, x0 + 3, 8, 1, 8)
            c.r(p, 0xFFd8c8a0, x0 + 1, 2, 1, 1)
        }
    }
    val door = bmp(16, 24) { c, p ->
        c.r(p, 0xFF5c3a1a, 1, 0, 14, 24); c.r(p, 0xFFa0693a, 2, 1, 12, 23)
        c.r(p, 0xFF84552c, 6, 1, 1, 23); c.r(p, 0xFF84552c, 10, 1, 1, 23)
        c.r(p, 0xFFffe08a, 5, 4, 6, 5); c.r(p, 0xFF5c3a1a, 8, 4, 1, 5); c.r(p, 0xFF5c3a1a, 5, 6, 6, 1)
        c.r(p, 0xFFf2c64a, 11, 14, 1, 2)
    }

    // ---- Scenery ----
    val tree = bmp(32, 48) { c, p ->
        c.r(p, 0xFF6b4a2a, 13, 28, 6, 20); c.r(p, 0xFF4e3420, 17, 28, 2, 20)
        c.r(p, 0xFF4e3420, 11, 45, 3, 3); c.r(p, 0xFF4e3420, 18, 45, 3, 3)
        blobs(c, p, 32, 34, listOf(intArrayOf(16, 17, 13), intArrayOf(8, 21, 8), intArrayOf(24, 21, 8), intArrayOf(16, 10, 9)),
            0xFF2f6a2c, 0xFF47923a, 0xFF5fae3e, 0xFF8fd45b, 7)
    }
    val bush = bmp(20, 12) { c, p ->
        blobs(c, p, 20, 12, listOf(intArrayOf(6, 7, 5), intArrayOf(13, 7, 6), intArrayOf(10, 5, 5)),
            0xFF2f6a2c, 0xFF47923a, 0xFF5fae3e, 0xFFf29bb8, 3)
    }
    val cloud = bmp(40, 14) { c, p ->
        blobs(c, p, 40, 14, listOf(intArrayOf(10, 9, 5), intArrayOf(19, 7, 7), intArrayOf(29, 9, 5), intArrayOf(20, 10, 6)),
            0xFFd5e6f5, 0xFFf4f9ff, 0xFFffffff, 0xFFffffff, 5)
    }
    val sun = bmp(12, 12) { c, p ->
        blobs(c, p, 12, 12, listOf(intArrayOf(6, 6, 5)), 0xFFf5c542, 0xFFffe066, 0xFFfff3a0, 0xFFfff3a0, 9)
    }
    private fun mkHills(col: Long, hi: Long, amp: Int, ph: Double, freq: Int) = bmp(192, 64) { c, p ->
        for (x in 0 until 192) {
            val t = x / 192.0 * 2 * PI
            val top = (24 + amp * sin(t * freq + ph) + amp / 2.0 * sin(t * freq * 3 + ph * 2)).toInt().coerceIn(2, 60)
            c.r(p, col, x, top, 1, 64 - top); c.r(p, hi, x, top, 1, 2)
        }
    }
    val hillFar = mkHills(0xFF8cc7a0, 0xFFa6d9b4, 10, 0.5, 2)
    val hillNear = mkHills(0xFF5fa85a, 0xFF7cc46c, 8, 2.0, 3)
    const val HILL_FAR_BASE = 0xFF8cc7a0
    const val HILL_NEAR_BASE = 0xFF5fa85a

    // ---- HUD ----
    private fun mkHeart(col: Long, hl: Long) = bmp(7, 6) { c, p ->
        val rows = listOf(".xx.xx.", "xxxxxxx", "xxxxxxx", ".xxxxx.", "..xxx..", "...x...")
        for ((y, r) in rows.withIndex()) for ((x, ch) in r.withIndex()) if (ch == 'x') c.r(p, col, x, y)
        c.r(p, hl, 1, 1)
    }
    val heartFull = mkHeart(0xFFd8322f, 0xFFff8a80)
    val heartEmpty = mkHeart(0xFF5a5a66, 0xFF7a7a86)

    // ---- Hero (16x26): straw hat, blue shirt. Frames: 0 idle, 1/2 run, 3 jump, 4 hang ----
    private fun mkPlayer(f: Int) = bmp(16, 26) { c, p ->
        val hat = 0xFFe8c15a; val brim = 0xFFc9a23f; val hair = 0xFF5a3418; val skin = 0xFFf2c18d
        val shirt = 0xFF3f8fd0; val shirtD = 0xFF2f6fa8; val pants = 0xFF3a3f6b; val boots = 0xFF4a2e1a; val belt = 0xFFc8a040
        c.r(p, hat, 5, 0, 6, 3); c.r(p, brim, 3, 3, 10, 1)
        c.r(p, hair, 4, 4, 1, 3); c.r(p, hair, 11, 4, 1, 3)
        c.r(p, skin, 5, 4, 6, 5); c.r(p, 0xFF222222, 9, 6, 1, 2); c.r(p, skin, 7, 9, 2, 1)
        c.r(p, shirt, 4, 10, 8, 7); c.r(p, shirtD, 4, 10, 1, 7); c.r(p, belt, 4, 16, 8, 1)
        when (f) {
            1 -> { c.r(p, shirt, 2, 11, 1, 5); c.r(p, skin, 2, 16); c.r(p, shirt, 13, 10, 1, 5); c.r(p, skin, 13, 15)
                   c.r(p, pants, 3, 17, 3, 6); c.r(p, boots, 2, 23, 4, 3); c.r(p, pants, 9, 17, 3, 6); c.r(p, boots, 9, 23, 4, 3) }
            2 -> { c.r(p, shirt, 3, 10, 1, 6); c.r(p, skin, 3, 16); c.r(p, shirt, 12, 10, 1, 6); c.r(p, skin, 12, 16)
                   c.r(p, pants, 6, 17, 3, 5); c.r(p, boots, 6, 22, 3, 3); c.r(p, pants, 7, 17, 3, 4); c.r(p, boots, 8, 21, 3, 2) }
            3 -> { c.r(p, shirt, 3, 6, 1, 5); c.r(p, skin, 3, 5); c.r(p, shirt, 12, 6, 1, 5); c.r(p, skin, 12, 5)
                   c.r(p, pants, 5, 17, 3, 4); c.r(p, boots, 4, 21, 3, 2); c.r(p, pants, 8, 17, 3, 5); c.r(p, boots, 9, 22, 3, 2) }
            4 -> { c.r(p, shirt, 3, 1, 1, 9); c.r(p, skin, 3, 0); c.r(p, shirt, 12, 1, 1, 9); c.r(p, skin, 12, 0)
                   c.r(p, pants, 5, 17, 3, 7); c.r(p, boots, 5, 24, 3, 2); c.r(p, pants, 8, 17, 3, 6); c.r(p, boots, 8, 23, 3, 2) }
            else -> { c.r(p, shirt, 3, 10, 1, 6); c.r(p, skin, 3, 16); c.r(p, shirt, 12, 10, 1, 6); c.r(p, skin, 12, 16)
                   c.r(p, pants, 5, 17, 3, 6); c.r(p, boots, 5, 23, 3, 3); c.r(p, pants, 8, 17, 3, 6); c.r(p, boots, 8, 23, 3, 3) }
        }
    }
    val player = List(5) { mkPlayer(it) }
}
